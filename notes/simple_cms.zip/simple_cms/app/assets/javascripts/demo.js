
function jsRoar(name) {
  alert('I am ' + name + '. Hear me roar!');
}
